// Drop ChatGPT artwork at these paths (see assets/README.md). Missing files fall back to simple shapes.
export const MANIFEST={
  player:'assets/player/player.png',
  tile1:'assets/tiles/tile_world1.png',tile2:'assets/tiles/tile_world2.png',tile3:'assets/tiles/tile_world3.png',tile4:'assets/tiles/tile_world4.png',
  bg1:'assets/backgrounds/bg_world1.png',bg2:'assets/backgrounds/bg_world2.png',bg3:'assets/backgrounds/bg_world3.png',bg4:'assets/backgrounds/bg_world4.png',
  coin:'assets/collectibles/coin.png',checkpoint:'assets/collectibles/checkpoint_off.png',checkpointOn:'assets/collectibles/checkpoint_on.png',exit:'assets/collectibles/exit_gate.png',
  spike:'assets/hazards/spike.png',drone:'assets/hazards/drone.png'};
const imgs={};
export function loadAssets(){for(const[k,src]of Object.entries(MANIFEST)){const i=new Image();i.onload=()=>{i.ok=true};i.src=src;imgs[k]=i}}
export const img=k=>imgs[k]&&imgs[k].ok?imgs[k]:null;
export function sprite(ctx,k,x,y,w,h,fx,fy,fallback){
  const i=img(k);if(!i){fallback&&fallback();return}
  ctx.save();ctx.translate(x+w/2,y+h/2);ctx.scale(fx?-1:1,fy?-1:1);ctx.drawImage(i,-w/2,-h/2,w,h);ctx.restore();
}
